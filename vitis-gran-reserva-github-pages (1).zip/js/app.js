// ===== Vitis Gran Reserva — aplicación principal (menú por rol + módulos) =====
const $ = (s, r = document) => r.querySelector(s);
const vista = $('#vista');

// Menú: cada opción declara qué permisos la habilitan.
// La interfaz solo OCULTA; el backend es quien realmente BLOQUEA (403).
const MENU = [
  { id: 'inicio', label: 'Inicio', icono: 'inicio' },
  { grupo: 'Operación' },
  { id: 'ventas', label: 'Ventas', icono: 'ventas', permisos: ['ventas.registrar', 'ventas.ver_propias', 'ventas.ver_todas'], desc: 'Emitir y consultar notas de venta', prueba: '/ventas' },
  { id: 'caja', label: 'Caja', icono: 'caja', permisos: ['caja.operar', 'caja.ver_todas'], desc: 'Apertura, movimientos y arqueo', prueba: '/caja/historial' },
  { id: 'asistencia', label: 'Mi asistencia', icono: 'asistencia', permisos: ['asistencia.marcar', 'asistencia.ver_propia'], desc: 'Marcar entrada/salida y ver mi historial', prueba: '/asistencia/mia' },
  { grupo: 'Administración' },
  { id: 'usuarios', label: 'Usuarios', icono: 'usuarios', permisos: ['usuarios.ver'], desc: 'Altas, edición, roles y bajas', prueba: '/usuarios' },
  { id: 'personal', label: 'Asistencia del personal', icono: 'equipo', permisos: ['asistencia.ver_todas'], desc: 'Control de entradas y salidas', prueba: '/asistencia/todas' },
  { id: 'auditoria', label: 'Auditoría', icono: 'auditoria', permisos: ['auditoria.ver'], desc: 'Log de actividad del sistema', prueba: '/auditoria' },
  { grupo: 'Cuenta' },
  { id: 'perfil', label: 'Mi cuenta', icono: 'perfil', desc: 'Cambiar contraseña y PIN' },
];
const permitido = (item) => !item.permisos || Sesion.puede(...item.permisos);

// Reglas de validación (las mismas que usa el backend)
const R = {
  nombre: /^[A-Za-zÁÉÍÓÚÜÑáéíóúüñ' ]{2,60}$/,
  ci: /^[0-9]{5,10}(-[0-9A-Za-z]{1,2})?$/,
  correo: /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/,
  telefono: /^[67][0-9]{7}$/,
  username: /^[a-z0-9._]{4,30}$/,
  pin: /^[0-9]{4,6}$/,
};
const claveOk = (p) => p.length >= 8 && /[A-Za-z]/.test(p) && /[0-9]/.test(p);

function rolBadge(rol) {
  const c = { Administrador: 'b-admin', Cajero: 'b-cajero', Empleado: 'b-empleado' }[rol] || 'b-off';
  return `<span class="badge ${c}">${esc(rol)}</span>`;
}
const estadoBadge = (e) => `<span class="badge ${e === 'ACTIVO' ? 'b-ok' : 'b-off'}">${e === 'ACTIVO' ? 'Activo' : 'Inactivo'}</span>`;

// ---------- Modal ----------
function abrirModal(html, { cerrable = true } = {}) {
  const m = $('#modal');
  m.innerHTML = `<div class="modal-fondo"><div class="modal" role="dialog" aria-modal="true">${html}</div></div>`;
  if (cerrable) {
    m.querySelector('.modal-fondo').addEventListener('mousedown', (e) => { if (e.target.classList.contains('modal-fondo')) cerrarModal(); });
    m.querySelectorAll('[data-cerrar]').forEach((b) => { b.onclick = cerrarModal; });
  }
  const primero = m.querySelector('input:not([type=hidden]), select');
  if (primero) setTimeout(() => primero.focus(), 30);
  return m.querySelector('.modal');
}
function cerrarModal() { $('#modal').innerHTML = ''; }
function confirmar(titulo, texto, etiqueta = 'Confirmar', clase = '') {
  return new Promise((ok) => {
    const m = abrirModal(`<h2>${esc(titulo)}</h2><p>${texto}</p>
      <div class="pie"><button class="btn sec" data-no>Cancelar</button><button class="btn ${clase}" data-si>${esc(etiqueta)}</button></div>`);
    m.querySelector('[data-no]').onclick = () => { cerrarModal(); ok(false); };
    m.querySelector('[data-si]').onclick = () => { cerrarModal(); ok(true); };
  });
}

// ---------- Sesión: cierre e inactividad ----------
async function cerrarSesion(motivo = 'SALIDA') {
  try { await api('POST', '/auth/logout', { motivo: motivo === 'SESION_EXPIRADA' ? 'INACTIVIDAD' : 'MANUAL' }); } catch { /* ya expirada */ }
  Sesion.limpiar();
  location.href = `index.html?motivo=${motivo}`;
}

(function vigilarInactividad() {
  const limite = Number(sessionStorage.getItem('inactividad') || 15) * 60000 - 20000; // un poco antes que el servidor
  let ultima = Date.now(); let ultimoPing = Date.now(); let avisado = false;
  const actividad = () => {
    ultima = Date.now(); avisado = false;
    // Mantiene viva la sesión en el servidor mientras el usuario trabaja (máx. 1 llamada por minuto)
    if (Date.now() - ultimoPing > 60000) {
      ultimoPing = Date.now();
      api('GET', '/auth/me').then((r) => Sesion.actualizarUsuario(r.usuario)).catch(() => {});
    }
  };
  ['click', 'keydown', 'mousemove', 'scroll', 'touchstart'].forEach((ev) => addEventListener(ev, actividad, { passive: true }));
  setInterval(() => {
    const quieto = Date.now() - ultima;
    if (quieto >= limite) cerrarSesion('SESION_EXPIRADA');
    else if (quieto >= limite - 60000 && !avisado) { avisado = true; toast('Su sesión se cerrará en 1 minuto por inactividad', 'aviso'); }
  }, 5000);
})();

// ---------- Estructura: menú y usuario ----------
function pintarMenu() {
  const u = Sesion.usuario;
  $('#logo').innerHTML = ICONOS.logo + 'Vitis Gran Reserva';
  let html = ''; let grupo = null;
  for (const item of MENU) {
    if (item.grupo) { grupo = item.grupo; continue; }
    if (!permitido(item)) continue;
    if (grupo) { html += `<div class="grupo">${grupo}</div>`; grupo = null; }
    html += `<a href="#${item.id}" data-id="${item.id}">${ICONOS[item.icono]}<span>${item.label}</span></a>`;
  }
  $('#menu').innerHTML = html;
  $('#usuarioBox').innerHTML = `<strong>${esc(u.nombres)} ${esc(u.apellidos)}</strong><span class="rol">${esc(u.rol)} · @${esc(u.username)}</span>
    <button class="btn mini" id="btnSalir">Cerrar sesión</button>`;
  $('#btnSalir').onclick = () => cerrarSesion('SALIDA');
  $('#abrirMenu').onclick = () => $('#lateral').classList.toggle('abierto');
}

async function navegar() {
  const id = location.hash.slice(1) || 'inicio';
  const item = MENU.find((m) => m.id === id) || MENU[0];
  document.querySelectorAll('.menu a').forEach((a) => a.classList.toggle('activo', a.dataset.id === item.id));
  $('#lateral').classList.remove('abierto');
  cerrarModal();
  if (!permitido(item)) return vistaDenegada(item);
  vista.innerHTML = '<p class="muted">Cargando…</p>';
  try { await VISTAS[item.id](); } catch (e) { vista.innerHTML = `<div class="alerta error">${esc(e.message)}</div>`; }
  if (Sesion.usuario.debe_cambiar_clave) forzarCambioClave();
}

/** Si el usuario escribe la URL de un módulo sin permiso, igual se consulta al servidor para demostrar el 403 */
async function vistaDenegada(item) {
  let respuesta = '';
  try { await api('GET', item.prueba); } catch (e) { respuesta = `${e.status || ''} — ${e.message}`; }
  vista.innerHTML = `<div class="panel denegado">
      <div class="codigo">403</div>
      <h2>Acceso denegado a “${esc(item.label)}”</h2>
      <p class="muted">Su rol <strong>${esc(Sesion.usuario.rol)}</strong> no tiene los permisos requeridos (${item.permisos.map(esc).join(', ')}).</p>
      <p class="small muted">Respuesta del servidor: <code>${esc(respuesta)}</code><br>El intento quedó registrado en la auditoría.</p>
      <a class="btn" href="#inicio">Volver al inicio</a></div>`;
}

// ======================= VISTAS =======================
const VISTAS = {};

// ---------- Inicio ----------
VISTAS.inicio = async () => {
  const u = Sesion.usuario;
  const hoy = new Date().toLocaleDateString('es-BO', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  const accesos = MENU.filter((m) => m.id && m.id !== 'inicio' && permitido(m));
  vista.innerHTML = `
    <div class="cabecera"><div><h1>Hola, ${esc(u.nombres)}</h1><p class="muted">${hoy}</p></div>${rolBadge(u.rol)}</div>
    <div class="kpis" id="kpis"></div>
    <div class="accesos">${accesos.map((m) => `<a class="acceso" href="#${m.id}">${ICONOS[m.icono]}<h3>${m.label}</h3><p>${m.desc}</p></a>`).join('')}</div>
    <div class="panel" style="margin-top:1.2rem"><h3>Permisos de su rol</h3>
      <div class="chips">${u.permisos.map((p) => `<span class="badge b-admin">${esc(p)}</span>`).join('')}</div></div>`;

  const kpis = [];
  if (Sesion.puede('usuarios.ver')) {
    const lista = await api('GET', '/usuarios');
    kpis.push(['Usuarios activos', lista.filter((x) => x.estado === 'ACTIVO').length], ['Usuarios inactivos', lista.filter((x) => x.estado !== 'ACTIVO').length]);
  }
  if (Sesion.puede('caja.operar')) {
    const c = await api('GET', '/caja/actual');
    kpis.push(c.caja ? ['Efectivo en mi caja', bs(c.resumen.esperado), true] : ['Mi caja', 'Cerrada']);
  }
  if (Sesion.puede('asistencia.ver_propia')) {
    const a = await api('GET', '/asistencia/mia');
    kpis.push(['Próxima marca', a.siguiente === 'ENTRADA' ? 'Entrada' : 'Salida', true]);
  }
  $('#kpis').innerHTML = kpis.map(([l, v, d]) => `<div class="kpi ${d ? 'destacado' : ''}"><div class="l">${l}</div><div class="v">${esc(v)}</div></div>`).join('');
};

// ---------- Usuarios (CRUD) ----------
let ROLES = [];
VISTAS.usuarios = async () => {
  ROLES = await api('GET', '/usuarios/roles');
  vista.innerHTML = `
    <div class="cabecera"><div><h1>Usuarios</h1><p class="muted">Gestión de cuentas, roles y accesos del personal.</p></div>
      ${Sesion.puede('usuarios.crear') ? '<button class="btn" id="btnNuevo">+ Nuevo usuario</button>' : ''}</div>
    <div class="toolbar">
      <input class="buscar" id="fBuscar" placeholder="Buscar por nombre, CI o usuario…">
      <select id="fRol"><option value="">Todos los roles</option>${ROLES.map((r) => `<option value="${r.id}">${esc(r.nombre)}</option>`).join('')}</select>
      <select id="fEstado"><option value="">Todos los estados</option><option value="ACTIVO">Activos</option><option value="INACTIVO">Inactivos</option></select>
    </div>
    <div class="tabla-wrap"><table>
      <thead><tr><th>Nombre</th><th>CI</th><th>Usuario</th><th>Correo</th><th>Teléfono</th><th>Rol</th><th>Estado</th><th></th></tr></thead>
      <tbody id="tUsuarios"></tbody></table></div>`;

  let t;
  const recargar = async () => {
    const q = new URLSearchParams({ q: $('#fBuscar').value, rol_id: $('#fRol').value, estado: $('#fEstado').value });
    const lista = await api('GET', `/usuarios?${q}`);
    $('#tUsuarios').innerHTML = lista.length ? lista.map((u) => `
      <tr class="${u.estado === 'ACTIVO' ? '' : 'inactivo'}">
        <td><strong>${esc(u.nombres)} ${esc(u.apellidos)}</strong>${u.debe_cambiar_clave ? '<br><span class="badge b-aviso">Clave temporal</span>' : ''}</td>
        <td>${esc(u.ci)}</td><td>@${esc(u.username)}</td><td>${esc(u.correo)}</td><td>${esc(u.telefono || '—')}</td>
        <td>${rolBadge(u.rol)}</td><td>${estadoBadge(u.estado)}</td>
        <td class="acciones">
          ${Sesion.puede('usuarios.editar') ? `<button class="btn sec mini" data-editar="${u.id}">Editar</button><button class="btn sec mini" data-reset="${u.id}" data-nombre="${esc(u.username)}">Clave</button>` : ''}
          ${Sesion.puede('usuarios.desactivar') && u.id !== Sesion.usuario.id
            ? (u.estado === 'ACTIVO'
              ? `<button class="btn peligro mini" data-estado="INACTIVO" data-id="${u.id}" data-nombre="${esc(u.username)}">Desactivar</button>`
              : `<button class="btn ok mini" data-estado="ACTIVO" data-id="${u.id}" data-nombre="${esc(u.username)}">Reactivar</button>`) : ''}
        </td></tr>`).join('') : '<tr><td colspan="8" class="vacio">No se encontraron usuarios</td></tr>';
  };
  $('#fBuscar').oninput = () => { clearTimeout(t); t = setTimeout(recargar, 250); };
  $('#fRol').onchange = recargar; $('#fEstado').onchange = recargar;
  if ($('#btnNuevo')) $('#btnNuevo').onclick = () => formUsuario(null, recargar);

  $('#tUsuarios').onclick = async (e) => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.editar) formUsuario(await api('GET', `/usuarios/${b.dataset.editar}`), recargar);
    if (b.dataset.reset) formResetClave(b.dataset.reset, b.dataset.nombre);
    if (b.dataset.estado) {
      const baja = b.dataset.estado === 'INACTIVO';
      const ok = await confirmar(baja ? 'Desactivar usuario' : 'Reactivar usuario',
        baja ? `<strong>@${esc(b.dataset.nombre)}</strong> ya no podrá ingresar al sistema ni marcar asistencia. Su historial de ventas, caja y asistencia <strong>se conserva</strong>.`
          : `<strong>@${esc(b.dataset.nombre)}</strong> podrá volver a ingresar al sistema.`,
        baja ? 'Desactivar' : 'Reactivar', baja ? 'peligro' : 'ok');
      if (!ok) return;
      try { const r = await api('PATCH', `/usuarios/${b.dataset.id}/estado`, { estado: b.dataset.estado }); toast(r.mensaje, 'ok'); recargar(); }
      catch (err) { toast(err.message, 'error'); }
    }
  };
  recargar();
};

function formUsuario(u, alGuardar) {
  const nuevo = !u; u = u || {};
  const campo = (name, label, attrs = '', req = true) => `<div class="campo"><label class="${req ? 'req' : ''}">${label}</label>
      <input name="${name}" value="${esc(u[name] || '')}" ${attrs}><div class="msg"></div></div>`;
  const m = abrirModal(`
    <h2>${nuevo ? 'Nuevo usuario' : `Editar @${esc(u.username)}`}</h2>
    <form id="fUsuario" novalidate>
      <div class="fila">${campo('nombres', 'Nombres')}${campo('apellidos', 'Apellidos')}</div>
      <div class="fila">${campo('ci', 'CI', 'placeholder="7845123"')}${campo('telefono', 'Celular', 'placeholder="71234567" inputmode="numeric"', false)}</div>
      ${campo('correo', 'Correo electrónico', 'type="email" placeholder="nombre@vitisgranreserva.bo"')}
      <div class="campo"><label class="req">Rol</label><select name="rol_id"><option value="">Seleccione…</option>
        ${ROLES.map((r) => `<option value="${r.id}" ${u.rol_id === r.id ? 'selected' : ''}>${esc(r.nombre)} — ${esc(r.descripcion)}</option>`).join('')}</select><div class="msg"></div></div>
      ${nuevo ? `
        <div class="fila">${campo('username', 'Nombre de usuario', 'placeholder="jperez" autocomplete="off"')}
          <div class="campo"><label class="req">PIN de asistencia</label><input name="pin" type="password" inputmode="numeric" maxlength="6" autocomplete="new-password"><div class="msg"></div></div></div>
        <div class="campo"><label class="req">Contraseña inicial</label><input name="password" type="password" autocomplete="new-password">
          <div class="msg"></div><div class="small muted">Temporal: el usuario deberá cambiarla al ingresar. Mín. 8 caracteres con letras y números.</div></div>` : ''}
      <div class="pie"><button type="button" class="btn sec" data-cerrar>Cancelar</button><button class="btn">${nuevo ? 'Crear usuario' : 'Guardar cambios'}</button></div>
    </form>`);
  const f = $('#fUsuario', m);
  f.onsubmit = async (e) => {
    e.preventDefault();
    const d = datosForm(f);
    const er = {};
    if (!R.nombre.test(d.nombres.trim())) er.nombres = d.nombres.trim() ? 'Solo letras y espacios' : 'Obligatorio';
    if (!R.nombre.test(d.apellidos.trim())) er.apellidos = d.apellidos.trim() ? 'Solo letras y espacios' : 'Obligatorio';
    if (!R.ci.test(d.ci.trim())) er.ci = d.ci.trim() ? 'CI inválido (ej. 7845123 o 7845123-1A)' : 'Obligatorio';
    if (d.telefono.trim() && !R.telefono.test(d.telefono.trim())) er.telefono = '8 dígitos, inicia con 6 o 7';
    if (!R.correo.test(d.correo.trim())) er.correo = d.correo.trim() ? 'Formato de correo inválido' : 'Obligatorio';
    if (!d.rol_id) er.rol_id = 'Seleccione un rol';
    if (nuevo) {
      if (!R.username.test(d.username.trim())) er.username = 'Minúsculas, números, . o _ (4 a 30)';
      if (!R.pin.test(d.pin)) er.pin = 'De 4 a 6 dígitos';
      if (!claveOk(d.password)) er.password = 'Mín. 8 caracteres con letras y números';
    }
    mostrarErrores(f, er);
    if (Object.keys(er).length) return;
    try {
      const r = nuevo ? await api('POST', '/usuarios', d) : await api('PUT', `/usuarios/${u.id}`, d);
      cerrarModal(); toast(r.mensaje, 'ok'); alGuardar();
    } catch (err) { mostrarErrores(f, err.campos); toast(err.message, 'error'); }
  };
}

function formResetClave(id, username) {
  const m = abrirModal(`<h2>Restablecer contraseña</h2>
    <p class="muted">Asigne una contraseña temporal a <strong>@${esc(username)}</strong>. Se cerrarán sus sesiones abiertas y deberá cambiarla al ingresar.</p>
    <form id="fReset" novalidate>
      <div class="campo"><label class="req">Contraseña temporal</label><input name="password" type="text" autocomplete="off"><div class="msg"></div></div>
      <div class="pie"><button type="button" class="btn sec" data-cerrar>Cancelar</button><button class="btn">Restablecer</button></div>
    </form>`);
  const f = $('#fReset', m);
  f.onsubmit = async (e) => {
    e.preventDefault();
    const d = datosForm(f);
    if (!claveOk(d.password)) return mostrarErrores(f, { password: 'Mín. 8 caracteres con letras y números' });
    try { const r = await api('POST', `/usuarios/${id}/reset-clave`, d); cerrarModal(); toast(r.mensaje, 'ok'); }
    catch (err) { mostrarErrores(f, err.campos); toast(err.message, 'error'); }
  };
}

// ---------- Caja ----------
VISTAS.caja = async () => {
  const opera = Sesion.puede('caja.operar');
  const actual = opera ? await api('GET', '/caja/actual') : { caja: null };
  const verTodas = Sesion.puede('caja.ver_todas');
  const historial = await api('GET', `/caja/historial${verTodas ? '?todas=1' : ''}`);
  const c = actual.caja;

  let html = `<div class="cabecera"><div><h1>Caja</h1><p class="muted">Cajero responsable: <strong>${esc(Sesion.usuario.nombres)} ${esc(Sesion.usuario.apellidos)}</strong></p></div>
    ${c ? `<span class="badge b-ok">Caja #${c.id} abierta desde ${fechaHora(c.fecha_apertura)}</span>` : '<span class="badge b-off">Sin caja abierta</span>'}</div>`;

  if (opera && !c) {
    html += `<div class="panel" style="max-width:420px"><h3>Abrir caja</h3>
      <form id="fAbrir" novalidate><div class="campo"><label class="req">Monto inicial (Bs)</label>
      <input name="monto_inicial" type="number" min="0" step="0.01" placeholder="200.00"><div class="msg"></div></div>
      <button class="btn">Abrir caja</button></form></div>`;
  }
  if (c) {
    const r = actual.resumen;
    html += `<div class="kpis">
        <div class="kpi"><div class="l">Monto inicial</div><div class="v">${bs(c.monto_inicial)}</div></div>
        <div class="kpi"><div class="l">Ingresos (${r.nro_ventas} ventas)</div><div class="v">${bs(r.ingresos)}</div></div>
        <div class="kpi"><div class="l">Egresos</div><div class="v">${bs(r.egresos)}</div></div>
        <div class="kpi destacado"><div class="l">Efectivo esperado</div><div class="v">${bs(r.esperado)}</div></div></div>
      <div class="grid-2">
        <div class="panel"><h3>Registrar movimiento</h3><form id="fMov" novalidate>
          <div class="fila"><div class="campo"><label class="req">Tipo</label><select name="tipo"><option value="INGRESO">Ingreso</option><option value="EGRESO">Egreso</option></select><div class="msg"></div></div>
          <div class="campo"><label class="req">Monto (Bs)</label><input name="monto" type="number" min="0.01" step="0.01"><div class="msg"></div></div></div>
          <div class="campo"><label class="req">Concepto</label><input name="concepto" placeholder="Ej. pago de transporte"><div class="msg"></div></div>
          <button class="btn sec">Registrar</button></form></div>
        <div class="panel"><h3>Cerrar caja (arqueo)</h3><form id="fCerrar" novalidate>
          <div class="campo"><label class="req">Efectivo contado (Bs)</label><input name="monto_contado" type="number" min="0" step="0.01"><div class="msg"></div></div>
          <p class="small" id="difPrev">Esperado: <strong>${bs(r.esperado)}</strong></p>
          <div class="campo"><label>Observaciones</label><input name="observaciones" maxlength="255"></div>
          <button class="btn">Cerrar caja</button></form></div>
      </div>
      <div class="panel"><h3>Movimientos de la caja actual</h3><div class="tabla-wrap"><table>
        <thead><tr><th>Hora</th><th>Tipo</th><th>Concepto</th><th class="num">Monto</th></tr></thead>
        <tbody>${actual.movimientos.length ? actual.movimientos.map((m) => `<tr><td>${fechaHora(m.fecha)}</td>
          <td><span class="badge ${m.tipo === 'INGRESO' ? 'b-ok' : 'b-error'}">${m.tipo}</span></td><td>${esc(m.concepto)}</td>
          <td class="num">${m.tipo === 'EGRESO' ? '−' : ''}${bs(m.monto)}</td></tr>`).join('') : '<tr><td colspan="4" class="vacio">Sin movimientos todavía</td></tr>'}</tbody></table></div></div>`;
  }

  html += `<div class="panel"><h3>${verTodas ? 'Historial de cajas (todos los cajeros)' : 'Mis cajas anteriores'}</h3><div class="tabla-wrap"><table>
    <thead><tr><th>#</th>${verTodas ? '<th>Cajero</th>' : ''}<th>Apertura</th><th>Cierre</th><th class="num">Inicial</th><th class="num">Esperado</th><th class="num">Contado</th><th class="num">Diferencia</th><th>Estado</th></tr></thead>
    <tbody>${historial.length ? historial.map((h) => `<tr><td>${h.id}</td>${verTodas ? `<td>${esc(h.cajero)}</td>` : ''}
      <td>${fechaHora(h.fecha_apertura)}</td><td>${fechaHora(h.fecha_cierre)}</td><td class="num">${bs(h.monto_inicial)}</td>
      <td class="num">${h.monto_esperado == null ? '—' : bs(h.monto_esperado)}</td><td class="num">${h.monto_contado == null ? '—' : bs(h.monto_contado)}</td>
      <td class="num">${h.diferencia == null ? '—' : `<span class="badge ${h.diferencia === 0 ? 'b-ok' : h.diferencia < 0 ? 'b-error' : 'b-aviso'}">${bs(h.diferencia)}</span>`}</td>
      <td><span class="badge ${h.estado === 'ABIERTA' ? 'b-ok' : 'b-off'}">${h.estado}</span></td></tr>`).join('') : `<tr><td colspan="9" class="vacio">Sin registros</td></tr>`}</tbody></table></div></div>`;
  vista.innerHTML = html;

  const enviar = (sel, url, validar, exito) => {
    const f = $(sel); if (!f) return;
    f.onsubmit = async (e) => {
      e.preventDefault();
      const d = datosForm(f); const er = validar(d);
      mostrarErrores(f, er); if (Object.keys(er).length) return;
      try { const r = await api('POST', url, d); toast(exito(r), 'ok'); VISTAS.caja(); }
      catch (err) { mostrarErrores(f, err.campos); toast(err.message, 'error'); }
    };
  };
  enviar('#fAbrir', '/caja/abrir', (d) => (d.monto_inicial === '' || Number(d.monto_inicial) < 0 ? { monto_inicial: 'Ingrese un monto ≥ 0' } : {}), (r) => r.mensaje);
  enviar('#fMov', '/caja/movimientos', (d) => {
    const e = {}; if (!(Number(d.monto) > 0)) e.monto = 'Mayor a 0'; if (d.concepto.trim().length < 3) e.concepto = 'Mínimo 3 caracteres'; return e;
  }, (r) => r.mensaje);
  enviar('#fCerrar', '/caja/cerrar', (d) => (d.monto_contado === '' || Number(d.monto_contado) < 0 ? { monto_contado: 'Ingrese el efectivo contado' } : {}),
    (r) => `Caja cerrada. Diferencia: ${bs(r.arqueo.diferencia)}`);
  if (c) {
    $('#fCerrar').monto_contado.oninput = (e) => {
      const dif = Number(e.target.value || 0) - actual.resumen.esperado;
      $('#difPrev').innerHTML = `Esperado: <strong>${bs(actual.resumen.esperado)}</strong> · Diferencia: <strong style="color:${Math.abs(dif) < 0.005 ? 'var(--ok)' : 'var(--error)'}">${bs(dif)}</strong>`;
    };
  }
};

// ---------- Ventas ----------
VISTAS.ventas = async () => {
  const registra = Sesion.puede('ventas.registrar');
  const todas = Sesion.puede('ventas.ver_todas');
  let html = `<div class="cabecera"><div><h1>Ventas</h1><p class="muted">Vendedor: <strong>${esc(Sesion.usuario.nombres)} ${esc(Sesion.usuario.apellidos)}</strong> (@${esc(Sesion.usuario.username)})</p></div></div>`;

  let productos = [];
  let caja = null;
  if (registra) {
    [productos, { caja }] = await Promise.all([api('GET', '/ventas/productos'), Sesion.puede('caja.operar') ? api('GET', '/caja/actual') : { caja: null }]);
    html += caja ? `<div class="panel"><h3>Nueva nota de venta</h3>
        <div class="fila"><div class="campo" style="grid-column:span 2"><label>Producto</label><select id="selProd">${productos.map((p) =>
          `<option value="${p.id}" ${p.stock ? '' : 'disabled'}>${esc(p.nombre)} · ${bs(p.precio)} · stock ${p.stock}</option>`).join('')}</select></div>
          <div class="campo"><label>Cantidad</label><input id="cant" type="number" min="1" value="1"></div>
          <div class="campo"><label>&nbsp;</label><button class="btn sec bloque" id="btnAgregar">Agregar</button></div></div>
        <div class="tabla-wrap"><table><thead><tr><th>Producto</th><th class="num">Precio</th><th class="num">Cant.</th><th class="num">Subtotal</th><th></th></tr></thead><tbody id="carrito"></tbody></table></div>
        <form id="fVenta" novalidate style="margin-top:1rem">
          <div class="fila"><div class="campo"><label>Cliente</label><input name="cliente_nombre" placeholder="Sin nombre"></div>
          <div class="campo"><label>CI / NIT</label><input name="cliente_ci_nit" inputmode="numeric"><div class="msg"></div></div></div>
          <div style="display:flex;justify-content:space-between;align-items:center;gap:1rem;flex-wrap:wrap">
            <div class="kpi destacado" style="min-width:200px"><div class="l">Total</div><div class="v" id="total">Bs 0,00</div></div>
            <button class="btn grande">Emitir nota de venta</button></div>
        </form></div>`
      : `<div class="alerta aviso">Para vender debe tener una caja abierta a su nombre. <a href="#caja">Abrir caja →</a></div>`;
  }
  const ventas = await api('GET', '/ventas');
  html += `<div class="panel"><h3>${todas ? 'Todas las ventas' : 'Mis ventas'}</h3><div class="tabla-wrap"><table>
    <thead><tr><th>Nota</th><th>Fecha</th><th>Cliente</th><th>Vendedor</th><th class="num">Total</th><th></th></tr></thead>
    <tbody>${ventas.length ? ventas.map((v) => `<tr><td><strong>${esc(v.nro_nota)}</strong></td><td>${fechaHora(v.fecha)}</td><td>${esc(v.cliente_nombre)}</td>
      <td>${esc(v.vendedor)}</td><td class="num">${bs(v.total)}</td><td class="acciones"><button class="btn sec mini" data-ver="${v.id}">Ver nota</button></td></tr>`).join('')
      : '<tr><td colspan="6" class="vacio">Aún no hay ventas</td></tr>'}</tbody></table></div></div>`;
  vista.innerHTML = html;

  vista.querySelectorAll('[data-ver]').forEach((b) => { b.onclick = async () => verNota(await api('GET', `/ventas/${b.dataset.ver}`)); });
  if (!registra || !caja) return;

  const carrito = [];
  const pintar = () => {
    $('#carrito').innerHTML = carrito.length ? carrito.map((i, k) => `<tr><td>${esc(i.nombre)}</td><td class="num">${bs(i.precio)}</td><td class="num">${i.cantidad}</td>
      <td class="num">${bs(i.precio * i.cantidad)}</td><td class="acciones"><button class="btn peligro mini" data-quitar="${k}">Quitar</button></td></tr>`).join('')
      : '<tr><td colspan="5" class="vacio">Agregue productos a la nota</td></tr>';
    $('#total').textContent = bs(carrito.reduce((s, i) => s + i.precio * i.cantidad, 0));
  };
  $('#btnAgregar').onclick = () => {
    const p = productos.find((x) => x.id === Number($('#selProd').value));
    const cant = Number($('#cant').value);
    if (!p || !Number.isInteger(cant) || cant < 1) return toast('Cantidad inválida', 'error');
    const ya = carrito.find((i) => i.producto_id === p.id);
    if ((ya ? ya.cantidad : 0) + cant > p.stock) return toast(`Stock insuficiente (disponible: ${p.stock})`, 'error');
    if (ya) ya.cantidad += cant; else carrito.push({ producto_id: p.id, nombre: p.nombre, precio: p.precio, cantidad: cant });
    $('#cant').value = 1; pintar();
  };
  $('#carrito').onclick = (e) => { const b = e.target.closest('[data-quitar]'); if (b) { carrito.splice(Number(b.dataset.quitar), 1); pintar(); } };
  $('#fVenta').onsubmit = async (e) => {
    e.preventDefault();
    const f = e.target; const d = datosForm(f);
    if (!carrito.length) return toast('Agregue al menos un producto', 'error');
    if (d.cliente_ci_nit.trim() && !/^[0-9]{5,13}(-[0-9A-Za-z]{1,2})?$/.test(d.cliente_ci_nit.trim())) return mostrarErrores(f, { cliente_ci_nit: 'Solo números (5 a 13)' });
    try {
      const r = await api('POST', '/ventas', { ...d, items: carrito.map(({ producto_id, cantidad }) => ({ producto_id, cantidad })) });
      toast(r.mensaje, 'ok');
      await VISTAS.ventas();
      verNota(await api('GET', `/ventas/${r.id}`));
    } catch (err) { mostrarErrores(f, err.campos); toast(err.message, 'error'); }
  };
  pintar();
};

function verNota(v) {
  abrirModal(`<div class="nota">
    <div class="enc"><div><h2 style="margin:0">Vitis Gran Reserva</h2><span class="muted small">Sucre, Bolivia</span></div>
      <div style="text-align:right"><strong>NOTA DE VENTA</strong><br>${esc(v.nro_nota)}<br><span class="small">${fechaHora(v.fecha)}</span></div></div>
    <p><strong>Vendedor:</strong> ${esc(v.vendedor)} (@${esc(v.vendedor_usuario)}) · ID usuario ${v.usuario_id}<br>
       <strong>Cliente:</strong> ${esc(v.cliente_nombre)}${v.cliente_ci_nit ? ` · CI/NIT ${esc(v.cliente_ci_nit)}` : ''}<br>
       <strong>Caja:</strong> #${v.caja_id}</p>
    <div class="tabla-wrap"><table><thead><tr><th>Código</th><th>Producto</th><th class="num">Cant.</th><th class="num">P. unit.</th><th class="num">Subtotal</th></tr></thead>
      <tbody>${v.detalle.map((d) => `<tr><td>${esc(d.codigo)}</td><td>${esc(d.nombre)}</td><td class="num">${d.cantidad}</td><td class="num">${bs(d.precio_unitario)}</td><td class="num">${bs(d.subtotal)}</td></tr>`).join('')}</tbody></table></div>
    <div class="total">Total: <strong>${bs(v.total)}</strong></div></div>
    <div class="pie"><button class="btn sec" data-cerrar>Cerrar</button></div>`);
}

// ---------- Mi asistencia ----------
VISTAS.asistencia = async () => {
  const datos = Sesion.puede('asistencia.ver_propia') ? await api('GET', '/asistencia/mia') : { siguiente: 'ENTRADA', dias: [] };
  vista.innerHTML = `<div class="cabecera"><div><h1>Mi asistencia</h1><p class="muted">Registro personal de entradas y salidas.</p></div></div>
    ${Sesion.puede('asistencia.marcar') ? `<div class="panel marcador">
      <div class="muted" id="hoy"></div><div class="hora" id="hora">--:--</div>
      <form id="fMarcar" novalidate><div class="campo"><input name="pin" type="password" inputmode="numeric" maxlength="6" placeholder="PIN" autocomplete="off"><div class="msg"></div></div>
      <button class="btn grande ${datos.siguiente === 'SALIDA' ? 'peligro' : ''}">Marcar ${datos.siguiente === 'ENTRADA' ? 'ENTRADA' : 'SALIDA'}</button></form></div>` : ''}
    <div class="panel"><h3>Últimos 30 días</h3>${tablaAsistencia(datos.dias, false)}</div>`;

  const reloj = () => { const h = $('#hora'); if (!h) return clearInterval(iv);
    const d = new Date(); h.textContent = d.toLocaleTimeString('es-BO', { hour: '2-digit', minute: '2-digit' });
    $('#hoy').textContent = d.toLocaleDateString('es-BO', { weekday: 'long', day: 'numeric', month: 'long' }); };
  const iv = setInterval(reloj, 1000); reloj();

  const f = $('#fMarcar');
  if (f) f.onsubmit = async (e) => {
    e.preventDefault();
    const d = datosForm(f);
    if (!R.pin.test(d.pin)) return mostrarErrores(f, { pin: 'Ingrese su PIN (4 a 6 dígitos)' });
    try { const r = await api('POST', '/asistencia/marcar', d); toast(r.mensaje, 'ok'); VISTAS.asistencia(); }
    catch (err) { mostrarErrores(f, err.campos); toast(err.message, 'error'); }
  };
};

function tablaAsistencia(dias, conEmpleado) {
  return `<div class="tabla-wrap"><table><thead><tr><th>Fecha</th>${conEmpleado ? '<th>Empleado</th>' : ''}<th>Marcas</th><th class="num">Horas</th><th>Estado</th></tr></thead>
    <tbody>${dias.length ? dias.map((d) => `<tr><td>${fecha(d.fecha)}</td>${conEmpleado ? `<td>${esc(d.empleado)}</td>` : ''}
      <td><div class="chips">${d.marcas.map((m) => `<span class="badge ${m.tipo === 'ENTRADA' ? 'b-ok' : 'b-cajero'}" title="${m.metodo}">${m.tipo === 'ENTRADA' ? '↓' : '↑'} ${m.hora}</span>`).join('')}</div></td>
      <td class="num">${d.horas}</td><td>${d.abierta ? '<span class="badge b-aviso">Sin salida</span>' : '<span class="badge b-ok">Completo</span>'}</td></tr>`).join('')
      : `<tr><td colspan="${conEmpleado ? 5 : 4}" class="vacio">Sin registros</td></tr>`}</tbody></table></div>`;
}

// ---------- Asistencia del personal (admin) ----------
VISTAS.personal = async () => {
  const usuarios = await api('GET', '/usuarios');
  const hace7 = new Date(Date.now() - 7 * 864e5).toISOString().slice(0, 10);
  vista.innerHTML = `<div class="cabecera"><div><h1>Asistencia del personal</h1><p class="muted">Entradas, salidas y horas trabajadas.</p></div></div>
    <div class="toolbar"><select id="aUsuario"><option value="">Todo el personal</option>${usuarios.map((u) => `<option value="${u.id}">${esc(u.nombres)} ${esc(u.apellidos)}</option>`).join('')}</select>
      <label class="small" style="margin:0">Desde</label><input type="date" id="aDesde" value="${hace7}"><label class="small" style="margin:0">Hasta</label><input type="date" id="aHasta"></div>
    <div id="tAsis"></div>`;
  const cargar = async () => {
    const q = new URLSearchParams({ usuario_id: $('#aUsuario').value, desde: $('#aDesde').value, hasta: $('#aHasta').value });
    $('#tAsis').innerHTML = tablaAsistencia(await api('GET', `/asistencia/todas?${q}`), true);
  };
  ['#aUsuario', '#aDesde', '#aHasta'].forEach((s) => { $(s).onchange = cargar; });
  cargar();
};

// ---------- Auditoría ----------
VISTAS.auditoria = async () => {
  const [acciones, usuarios] = await Promise.all([api('GET', '/auditoria/acciones'), api('GET', '/usuarios')]);
  vista.innerHTML = `<div class="cabecera"><div><h1>Auditoría</h1><p class="muted">Inicios de sesión, cambios de clave, altas y bajas de cuentas, y otras acciones clave.</p></div></div>
    <div class="toolbar"><select id="fAcc"><option value="">Todas las acciones</option>${acciones.map((a) => `<option>${esc(a)}</option>`).join('')}</select>
      <select id="fUsu"><option value="">Todos los usuarios</option>${usuarios.map((u) => `<option value="${u.id}">@${esc(u.username)}</option>`).join('')}</select>
      <input type="date" id="fDes"><input type="date" id="fHas"></div>
    <div class="tabla-wrap"><table><thead><tr><th>Fecha y hora</th><th>Usuario</th><th>Acción</th><th>Detalle</th><th>IP</th></tr></thead><tbody id="tAud"></tbody></table></div>`;
  const color = (a) => (/FALLIDO|DENEGADO|BLOQUEADA|RECHAZADO|DESACTIVADO/.test(a) ? 'b-error' : /EXPIRADA|RESET|CAMBIO/.test(a) ? 'b-aviso' : /LOGIN_OK|CREADO|REACTIVADO/.test(a) ? 'b-ok' : 'b-off');
  const cargar = async () => {
    const q = new URLSearchParams({ accion: $('#fAcc').value, usuario_id: $('#fUsu').value, desde: $('#fDes').value, hasta: $('#fHas').value });
    const filas = await api('GET', `/auditoria?${q}`);
    $('#tAud').innerHTML = filas.length ? filas.map((f) => `<tr><td style="white-space:nowrap">${fechaHora(f.fecha)}</td><td>${f.username ? '@' + esc(f.username) : '<span class="muted">—</span>'}</td>
      <td><span class="badge ${color(f.accion)}">${esc(f.accion)}</span></td><td>${esc(f.detalle || '')}</td><td class="small muted">${esc(f.ip || '')}</td></tr>`).join('')
      : '<tr><td colspan="5" class="vacio">Sin registros para este filtro</td></tr>';
  };
  ['#fAcc', '#fUsu', '#fDes', '#fHas'].forEach((s) => { $(s).onchange = cargar; });
  cargar();
};

// ---------- Mi cuenta ----------
VISTAS.perfil = async () => {
  const u = Sesion.usuario;
  vista.innerHTML = `<div class="cabecera"><div><h1>Mi cuenta</h1><p class="muted">${esc(u.nombres)} ${esc(u.apellidos)} · @${esc(u.username)} · ${esc(u.correo)}</p></div>${rolBadge(u.rol)}</div>
    <div class="grid-2">
      <div class="panel"><h3>Cambiar contraseña</h3><form id="fClave" novalidate>
        <div class="campo"><label class="req">Contraseña actual</label><input name="actual" type="password" autocomplete="current-password"><div class="msg"></div></div>
        <div class="campo"><label class="req">Nueva contraseña</label><input name="nueva" type="password" autocomplete="new-password"><div class="msg"></div></div>
        <div class="campo"><label class="req">Repetir nueva contraseña</label><input name="repetir" type="password" autocomplete="new-password"><div class="msg"></div></div>
        <button class="btn">Actualizar contraseña</button></form></div>
      <div class="panel"><h3>Cambiar PIN de asistencia</h3><form id="fPin" novalidate>
        <div class="campo"><label class="req">Contraseña</label><input name="password" type="password" autocomplete="current-password"><div class="msg"></div></div>
        <div class="campo"><label class="req">Nuevo PIN</label><input name="pin" type="password" inputmode="numeric" maxlength="6" autocomplete="off"><div class="msg"></div></div>
        <button class="btn sec">Actualizar PIN</button></form></div>
    </div>`;
  formClave($('#fClave'), () => vista.querySelector('#fClave').reset());
  const fp = $('#fPin');
  fp.onsubmit = async (e) => {
    e.preventDefault();
    const d = datosForm(fp); const er = {};
    if (!d.password) er.password = 'Obligatorio'; if (!R.pin.test(d.pin)) er.pin = 'De 4 a 6 dígitos';
    mostrarErrores(fp, er); if (Object.keys(er).length) return;
    try { const r = await api('PUT', '/auth/pin', d); toast(r.mensaje, 'ok'); fp.reset(); }
    catch (err) { mostrarErrores(fp, err.campos); toast(err.message, 'error'); }
  };
};

function formClave(f, alTerminar) {
  f.onsubmit = async (e) => {
    e.preventDefault();
    const d = datosForm(f); const er = {};
    if (!d.actual) er.actual = 'Obligatorio';
    if (!claveOk(d.nueva)) er.nueva = 'Mín. 8 caracteres con letras y números';
    else if (d.nueva === d.actual) er.nueva = 'Debe ser distinta a la actual';
    if (d.repetir !== d.nueva) er.repetir = 'Las contraseñas no coinciden';
    mostrarErrores(f, er); if (Object.keys(er).length) return;
    try {
      const r = await api('PUT', '/auth/clave', { actual: d.actual, nueva: d.nueva });
      Sesion.actualizarUsuario({ ...Sesion.usuario, debe_cambiar_clave: false });
      toast(r.mensaje, 'ok'); alTerminar();
    } catch (err) { mostrarErrores(f, err.campos); toast(err.message, 'error'); }
  };
}

/** Primer ingreso o clave reseteada: no se puede usar el sistema hasta cambiarla */
function forzarCambioClave() {
  const m = abrirModal(`<h2>${ICONOS.candado.replace('<svg', '<svg style="width:22px;height:22px;vertical-align:-4px;color:var(--vino)"')} Cambie su contraseña</h2>
    <p class="muted">Está usando una contraseña temporal asignada por el administrador. Por seguridad, defina una nueva para continuar.</p>
    <form id="fForzar" novalidate>
      <div class="campo"><label class="req">Contraseña temporal</label><input name="actual" type="password"><div class="msg"></div></div>
      <div class="campo"><label class="req">Nueva contraseña</label><input name="nueva" type="password"><div class="msg"></div></div>
      <div class="campo"><label class="req">Repetir nueva contraseña</label><input name="repetir" type="password"><div class="msg"></div></div>
      <div class="pie"><button type="button" class="btn sec" id="salirForzar">Cerrar sesión</button><button class="btn">Guardar y continuar</button></div>
    </form>`, { cerrable: false });
  $('#salirForzar', m).onclick = () => cerrarSesion('SALIDA');
  formClave($('#fForzar', m), cerrarModal);
}

// ---------- Arranque ----------
(async function iniciar() {
  try {
    const r = await api('GET', '/auth/me'); // valida la sesión y trae permisos actualizados
    Sesion.actualizarUsuario(r.usuario);
  } catch { return; }
  pintarMenu();
  addEventListener('hashchange', navegar);
  navegar();
})();
